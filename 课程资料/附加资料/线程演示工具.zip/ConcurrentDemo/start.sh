java -cp bin:lib/auto.jar:lib/edit.jar concurent.Demo
